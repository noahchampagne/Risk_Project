Project Name: Risk Remade
Project Desc: This project is a recreation of the game, RISK, a strategy-based game centered around the goal of world domination. The game is conducted in a turn-based fashion and requires between 2-4 players. The project UI will overlay a world map where players can click on certain countries in order to battle and quest for domination over other countries. To win, a player must dominate all of the world's countries through battles with the other players.

Game Instruction: To play risk, the user should unzip the ZIP file. Once opened, the user should simply open the file named "15-112 Term Project V.5.py" and run it. This project only uses built-in modules in conjunction with the CMU 112 Graphics Package also in the ZIP File.

Additional Libraries: None

Shortcuts:

Once the user has input how many players they would like to play, they can press the key 'p' in order to use the first shortcut.
***Pressing 'p' in this initial placement screen will place all of the initial troops.

Only after this shortcut can the user then press 'k' to initiate the second shortcut.
***Pressing 'k' will skip over the majority of the game to the point where one player has dominated the whole world except for 1 country.